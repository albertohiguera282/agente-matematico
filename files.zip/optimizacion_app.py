"""
optimizacion_app.py
Módulo de Optimización — Agent-Math
Streamlit UI para los 6 modelos de optimización.
"""

import streamlit as st
import numpy as np
import pandas as pd
from optimizacion import (
    resolver_programacion_lineal_grafico,
    resolver_programacion_lineal_simplex,
    resolver_programacion_lineal_entera,
    analizar_sensibilidad,
    resolver_transporte,
    resolver_asignacion,
)

# ══════════════════════════════════════════════════════
#  Helpers de UI
# ══════════════════════════════════════════════════════
def _label_opt(tipo):
    return "Maximizar" if tipo == "max" else "Minimizar"

def _parse_fo(text, n):
    """Convierte string 'c1,c2,...,cn' a lista de floats."""
    vals = [float(v.strip()) for v in text.split(",")]
    if len(vals) != n:
        raise ValueError(f"Se esperaban {n} coeficientes, se recibieron {len(vals)}.")
    return vals

def _render_result_box(title, content_dict):
    st.markdown(f"### ✅ {title}")
    for k, v in content_dict.items():
        st.markdown(f"**{k}:** `{v}`")

# ══════════════════════════════════════════════════════
#  Sección principal
# ══════════════════════════════════════════════════════
def mostrar_optimizacion():
    st.title("📐 Optimización — Programación Lineal y Extensiones")

    tabs = st.tabs([
        "1️⃣  Gráfico 2D",
        "2️⃣  Simplex N-Variables",
        "3️⃣  PL Entera",
        "4️⃣  Sensibilidad",
        "5️⃣  Transporte",
        "6️⃣  Asignación",
    ])

    # ──────────────────────────────────────────────
    # TAB 1 — Gráfico 2D
    # ──────────────────────────────────────────────
    with tabs[0]:
        st.subheader("Método Gráfico (2 variables)")
        st.markdown(
            "Resuelve **Z = c₁·x₁ + c₂·x₂** sujeto a restricciones "
            "de la forma **a·x₁ + b·x₂ ≤ rhs** y x₁, x₂ ≥ 0."
        )

        col1, col2 = st.columns(2)
        with col1:
            c1 = st.number_input("Coeficiente c₁ (x₁)", value=5.0, key="g_c1")
            c2 = st.number_input("Coeficiente c₂ (x₂)", value=4.0, key="g_c2")
            tipo = st.selectbox("Tipo", ["max", "min"], key="g_tipo")

        with col2:
            n_rest = st.number_input("Número de restricciones", min_value=1,
                                     max_value=8, value=2, step=1, key="g_nrest")

        st.markdown("**Define cada restricción** (a·x₁ + b·x₂ ≤ rhs):")
        restricciones = []
        cols_r = st.columns(3)
        for i in range(int(n_rest)):
            with cols_r[0]:
                a = st.number_input(f"a{i+1}", value=1.0, key=f"ga{i}")
            with cols_r[1]:
                b = st.number_input(f"b{i+1}", value=1.0, key=f"gb{i}")
            with cols_r[2]:
                rhs = st.number_input(f"rhs{i+1}", value=6.0, key=f"gr{i}")
            restricciones.append((a, b, rhs))

        if st.button("Resolver gráficamente", key="btn_graf"):
            try:
                res = resolver_programacion_lineal_grafico(
                    (c1, c2), restricciones, tipo
                )
                x_opt, y_opt = res["Punto_Optimo"]
                st.success(
                    f"**Punto óptimo:** x₁ = {x_opt:.4f}, x₂ = {y_opt:.4f}  |  "
                    f"**Z = {res['Z_Optimo']:.4f}**"
                )
                st.pyplot(res["Fig"])
                st.markdown("#### Tabla de vértices evaluados")
                st.dataframe(pd.DataFrame(res["Vertices_Evaluados"]), use_container_width=True)
            except Exception as e:
                st.error(f"Error: {e}")

    # ──────────────────────────────────────────────
    # TAB 2 — Simplex N variables
    # ──────────────────────────────────────────────
    with tabs[1]:
        st.subheader("Método Simplex — N Variables")
        st.markdown(
            "Ingresa los coeficientes de la **función objetivo** y de cada "
            "**restricción** (≤) separados por comas."
        )

        tipo_s = st.selectbox("Tipo de optimización", ["max", "min"], key="s_tipo")
        n_vars_s = st.number_input("Número de variables", 2, 10, 3, key="s_nv")
        n_rest_s = st.number_input("Número de restricciones (≤)", 1, 15, 3, key="s_nr")

        fo_input = st.text_input(
            f"Función objetivo ({int(n_vars_s)} coefs, separados por coma)",
            value=",".join(["40", "30", "50"][:int(n_vars_s)] +
                           ["10"] * max(0, int(n_vars_s) - 3)),
            key="s_fo",
        )

        st.markdown("**Restricciones** (una por fila — coefs separados por coma):")
        rest_inputs = []
        rhs_inputs  = []
        for i in range(int(n_rest_s)):
            c_col, r_col = st.columns([3, 1])
            with c_col:
                ri = st.text_input(
                    f"Coefs restricción {i+1}",
                    value=",".join(["1"] * int(n_vars_s)),
                    key=f"sr_coef{i}",
                )
            with r_col:
                bi = st.number_input(f"RHS {i+1}", value=100.0, key=f"sr_rhs{i}")
            rest_inputs.append(ri)
            rhs_inputs.append(bi)

        if st.button("Resolver con Simplex", key="btn_simplex"):
            try:
                fo  = _parse_fo(fo_input, int(n_vars_s))
                A   = [_parse_fo(r, int(n_vars_s)) for r in rest_inputs]
                b   = list(rhs_inputs)
                res = resolver_programacion_lineal_simplex(fo, A, b, tipo_s)
                if res["Estado"] == "Óptimo":
                    st.success(f"**Valor óptimo Z = {res['Valor_Optimo']}**")
                    st.dataframe(
                        pd.DataFrame(res["Variables"].items(),
                                     columns=["Variable", "Valor"]),
                        use_container_width=True,
                    )
                else:
                    st.warning(f"{res['Estado']}: {res.get('Mensaje','')}")
            except Exception as e:
                st.error(f"Error: {e}")

    # ──────────────────────────────────────────────
    # TAB 3 — PL Entera
    # ──────────────────────────────────────────────
    with tabs[2]:
        st.subheader("Programación Lineal Entera / Mixta")
        st.markdown(
            "Igual que Simplex pero puedes forzar que **algunas o todas** las "
            "variables tomen valores **enteros**."
        )

        tipo_e = st.selectbox("Tipo", ["max", "min"], key="e_tipo")
        n_vars_e = st.number_input("Número de variables", 2, 10, 3, key="e_nv")
        n_rest_e = st.number_input("Número de restricciones (≤)", 1, 15, 2, key="e_nr")
        todas_enteras = st.checkbox("Todas las variables enteras", value=True, key="e_all")

        fo_e = st.text_input(
            f"Función objetivo ({int(n_vars_e)} coefs)",
            value=",".join(["5", "8", "3"][:int(n_vars_e)] +
                           ["4"] * max(0, int(n_vars_e) - 3)),
            key="e_fo",
        )

        rest_e, rhs_e = [], []
        for i in range(int(n_rest_e)):
            cc, rc = st.columns([3, 1])
            with cc:
                ri = st.text_input(
                    f"Coefs restricción {i+1}",
                    value=",".join(["1"] * int(n_vars_e)),
                    key=f"er_coef{i}",
                )
            with rc:
                bi = st.number_input(f"RHS {i+1}", value=10.0, key=f"er_rhs{i}")
            rest_e.append(ri); rhs_e.append(bi)

        vars_enteras_sel = None
        if not todas_enteras:
            opts = [f"X{i+1}" for i in range(int(n_vars_e))]
            sel  = st.multiselect("Variables enteras", opts, default=opts[:1], key="e_sel")
            vars_enteras_sel = [int(s[1:]) - 1 for s in sel]

        if st.button("Resolver PL Entera", key="btn_entera"):
            try:
                fo  = _parse_fo(fo_e, int(n_vars_e))
                A   = [_parse_fo(r, int(n_vars_e)) for r in rest_e]
                b   = list(rhs_e)
                res = resolver_programacion_lineal_entera(
                    fo, A, b, vars_enteras_sel if not todas_enteras else None, tipo_e
                )
                if "Óptimo" in res["Estado"]:
                    st.success(f"**Valor óptimo Z = {res['Valor_Optimo']}**")
                    st.dataframe(
                        pd.DataFrame(res["Variables"].items(),
                                     columns=["Variable", "Valor"]),
                        use_container_width=True,
                    )
                else:
                    st.warning(f"{res['Estado']}: {res.get('Mensaje','')}")
            except Exception as e:
                st.error(f"Error: {e}")

    # ──────────────────────────────────────────────
    # TAB 4 — Análisis de Sensibilidad
    # ──────────────────────────────────────────────
    with tabs[3]:
        st.subheader("Análisis de Sensibilidad")
        st.markdown(
            "Calcula el **rango** en el que cada coeficiente de la FO "
            "y cada RHS puede variar sin cambiar la base óptima."
        )

        tipo_as = st.selectbox("Tipo", ["max", "min"], key="as_tipo")
        n_vars_as = st.number_input("Número de variables", 2, 8, 2, key="as_nv")
        n_rest_as = st.number_input("Número de restricciones", 1, 10, 2, key="as_nr")

        fo_as = st.text_input(
            f"Función objetivo ({int(n_vars_as)} coefs)",
            value=",".join(["5", "4"][:int(n_vars_as)] + ["3"] * max(0, int(n_vars_as)-2)),
            key="as_fo",
        )
        rest_as, rhs_as = [], []
        for i in range(int(n_rest_as)):
            cc, rc = st.columns([3, 1])
            with cc:
                ri = st.text_input(f"Coefs R{i+1}",
                                   value=",".join(["1"] * int(n_vars_as)),
                                   key=f"as_c{i}")
            with rc:
                bi = st.number_input(f"RHS {i+1}", value=6.0, key=f"as_r{i}")
            rest_as.append(ri); rhs_as.append(bi)

        if st.button("Analizar sensibilidad", key="btn_sens"):
            try:
                fo  = _parse_fo(fo_as, int(n_vars_as))
                A   = [_parse_fo(r, int(n_vars_as)) for r in rest_as]
                b   = list(rhs_as)
                res = analizar_sensibilidad(fo, A, b, tipo_as)
                base = res["Solucion_Base"]
                if base["Estado"] == "Óptimo":
                    st.success(f"**Z óptimo = {base['Valor_Optimo']}**")
                    st.dataframe(
                        pd.DataFrame(base["Variables"].items(),
                                     columns=["Variable", "Valor"]),
                        use_container_width=True,
                    )
                    st.markdown("#### Sensibilidad de la Función Objetivo")
                    st.dataframe(res["Sensibilidad_FO"], use_container_width=True)
                    st.markdown("#### Sensibilidad del RHS")
                    df_rhs = res["Sensibilidad_RHS"].copy()
                    df_rhs["Holgura"] = res["Holguras"]
                    st.dataframe(df_rhs, use_container_width=True)
                else:
                    st.warning(f"{base['Estado']}: {base.get('Mensaje','')}")
            except Exception as e:
                st.error(f"Error: {e}")

    # ──────────────────────────────────────────────
    # TAB 5 — Transporte
    # ──────────────────────────────────────────────
    with tabs[4]:
        st.subheader("Problema de Transporte")
        st.markdown(
            "Minimiza el costo total de enviar unidades desde **m orígenes** "
            "a **n destinos**."
        )

        col_m, col_n = st.columns(2)
        with col_m:
            m_t = st.number_input("Orígenes (m)", 2, 6, 3, key="t_m")
        with col_n:
            n_t = st.number_input("Destinos (n)", 2, 6, 3, key="t_n")

        m_t = int(m_t); n_t = int(n_t)

        st.markdown("**Oferta por origen:**")
        oferta = [st.number_input(f"Oferta O{i+1}", value=30.0, key=f"to{i}")
                  for i in range(m_t)]

        st.markdown("**Demanda por destino:**")
        demanda = [st.number_input(f"Demanda D{j+1}", value=round(sum(oferta)/n_t, 1),
                                   key=f"td{j}")
                   for j in range(n_t)]

        st.markdown("**Matriz de costos** (fila = origen, columna = destino):")
        costos = []
        for i in range(m_t):
            fila = []
            cols_c = st.columns(n_t)
            for j in range(n_t):
                with cols_c[j]:
                    c_val = st.number_input(f"c[{i+1},{j+1}]",
                                            value=float((i + 1) * (j + 1)),
                                            key=f"tc{i}{j}")
                fila.append(c_val)
            costos.append(fila)

        if st.button("Resolver Transporte", key="btn_transp"):
            try:
                res = resolver_transporte(
                    [float(o) for o in oferta],
                    [float(d) for d in demanda],
                    costos
                )
                if res["Estado"] == "Óptimo":
                    st.success(f"**Costo total mínimo = {res['Costo_Total']}**")
                    st.markdown("#### Tabla de asignación (unidades)")
                    st.dataframe(res["Tabla_Asignacion"], use_container_width=True)
                else:
                    st.warning(res["Mensaje"])
            except Exception as e:
                st.error(f"Error: {e}")

    # ──────────────────────────────────────────────
    # TAB 6 — Asignación
    # ──────────────────────────────────────────────
    with tabs[5]:
        st.subheader("Problema de Asignación")
        st.markdown(
            "Asigna **n agentes** a **n tareas** (uno a uno) minimizando "
            "el costo total o maximizando el beneficio."
        )

        n_a = st.number_input("Dimensión n (agentes = tareas)", 2, 8, 3, key="a_n")
        n_a = int(n_a)
        tipo_a = st.selectbox("Tipo", ["min", "max"], key="a_tipo")

        st.markdown("**Matriz de costos/beneficios** (fila = agente, columna = tarea):")
        costos_a = []
        for i in range(n_a):
            fila = []
            cols_a = st.columns(n_a)
            for j in range(n_a):
                with cols_a[j]:
                    c_val = st.number_input(
                        f"[{i+1},{j+1}]",
                        value=float(np.random.randint(1, 20)
                                    if False else (i * n_a + j + 1)),
                        key=f"ac{i}{j}",
                    )
                fila.append(c_val)
            costos_a.append(fila)

        if st.button("Resolver Asignación", key="btn_asig"):
            try:
                res = resolver_asignacion(costos_a, tipo_a)
                if res["Estado"] == "Óptimo":
                    st.success(f"**Valor óptimo = {res['Valor_Optimo']}**")
                    st.markdown("#### Asignaciones óptimas")
                    df_asig = pd.DataFrame(res["Asignaciones"],
                                           columns=["Agente", "Tarea", "Costo/Beneficio"])
                    st.dataframe(df_asig, use_container_width=True)
                    st.markdown("#### Matriz de asignación (1 = asignado)")
                    st.dataframe(res["Tabla"], use_container_width=True)
                else:
                    st.warning(res["Mensaje"])
            except Exception as e:
                st.error(f"Error: {e}")


# ══════════════════════════════════════════════════════
#  Entry point (ejecutar módulo directamente)
# ══════════════════════════════════════════════════════
if __name__ == "__main__":
    mostrar_optimizacion()
